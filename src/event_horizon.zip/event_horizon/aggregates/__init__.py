from .base_aggregate import Aggregate
from .light_aggregate import LightAggregate
